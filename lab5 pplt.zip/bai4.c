#include <stdio.h>
#include <string.h>
#define A 1000

void DinhDang(char a[])
{
    int n = strlen(a);
    for (int i = 0; i < n; i++)
    {
        if (a[i] == ' ' && a[i + 1] == ' ')
        {
            for (int j = i; j < n; j++)
            {
                a[j] = a[j + 1]; // xoa khoang trang.
            }
            --n; // cap nhat do dai chuoi.
            --i; // xoa o vi tri cu neu co.
        }
    }
}

void InChuan(char a[])
{
    for (int i = 0; a[i] != '\0'; i++)
    {
        if (a[i] >= 'A' && a[i] <= 'Z') // neu in hoa tra ve in thuong.
        {
            a[i] = a[i] + 32;
        }
        if (a[i - 1] == ' ' || i == 0) // chu cai dau tien hoac phia truoc la khoang trang tra ve in hoa.
        {
            if (a[i] >= 'a' && a[i] <= 'z')
            a[i] = a[i] - 32;
        }
        
    }
}
int main()
{
    char a[A];
    printf("\nNhap chuoi bat ki: ");
    fgets(a, A, stdin);

    printf("\nChuoi ban da nhap: %s", a);

    DinhDang(a);

    InChuan(a);
    printf("\nSau khi dinh dang: %s", a);
}