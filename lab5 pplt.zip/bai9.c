#include<stdio.h>
#include <string.h>
#define A 1000

int S2inS1(char a[], char b[])
{
    int j = 0, temp = 0;
    for (int i = 0; i < strlen(a) - 1; i++)
    {
        if (a[i] == b[j] && a[i + 1] == b[j + 1])
        {
            temp = i;
            break;
        }
    }
    return temp + 1;
}

int main()
{
    char a[A], b[A];
    printf("\n-----Nhap vao chuoi thu 1-----\n");
    fgets(a, A, stdin);

    printf("\n-----Nhap vao chuoi thu 2-----\n");
    fgets(b, A, stdin);

    printf("\n-----Vi tri chuoi 2 xuat hien dau tien trong chuoi 1-----\n");
    printf("%d", S2inS1(a, b));
}