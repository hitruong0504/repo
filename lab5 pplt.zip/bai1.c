#include <stdio.h>
#include <string.h>
#define A 1000

int DoDaiChuoi(char a[])
{
    int count = 0;
    while (a[count] != '\0')
    {
        count++;
    }
    return count - 1;
}


int main()
{
    char a[A];
    printf("\nNhap vao chuoi bat ki: ");
    fgets(a, A, stdin);
    printf("\nDo dai cua chuoi '%s' la %d.", a, DoDaiChuoi(a)); // cach 1
    printf("\nDo dai cua chuoi '%s' la %d.", a, strlen(a) - 1); // cach 2
}