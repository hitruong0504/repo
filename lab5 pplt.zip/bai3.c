#include <stdio.h>
#include <string.h>
#define A 100

void XDHo(char hovaten[], char ho[])
{
    for (int i = 0; hovaten[i] != ' '; i++)
    {
        ho[i] = hovaten[i];
    }
}

void XDTen(char hovaten[], char ten[])
{
    int i, j;
    for (i = strlen(hovaten); i > 0; i--)
    {
        if (hovaten[i] == ' ')
        {
            break;
        }
    }
    for (j = 0; hovaten[j] != '\0'; i++, j++)
    {
        ten[j] = hovaten[i + 1];
    }
}

int main()
{
    char hovaten[A], ho[A], ten[A];
    printf("\nNhap vao ho vao ten: ");
    fgets(hovaten, A, stdin);

    XDHo(hovaten, ho);
    printf("\nHo la: %s", ho);

    XDTen(hovaten, ten);
    printf("\nTen la: %s", ten);
}