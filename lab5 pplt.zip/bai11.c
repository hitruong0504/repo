#include <stdio.h>
#define A 1000

void Xoa(char a[], int n, int p)
{
    int t = 0;
    for (int i = p; i < n + p; i++)
    {
        a[i] = a[n + p + t];
        t++;
    }
}

int main()
{
    char a[A];
    int n, p;
    printf("\n-----Nhap vao chuoi bat ky-----\n");
    fgets(a, A, stdin);

    printf("\n-----Nhap vao so n nguyen duong-----\n");
    scanf("%d", &n);

    printf("\n-----Nhap vao vi tri can xoa n ky tu-----\n");
    scanf("%d", &p);

    Xoa(a, n, p);
    printf("\n-----Chuoi sau khi xoa-----\n");
    printf("%s", a);
}