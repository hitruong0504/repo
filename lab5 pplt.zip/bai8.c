#include <stdio.h>
#include <string.h>
#define A 1000

int ViTriDauTien(char a[])
{
    int temp;
    for (int i = 0; i < strlen(a) - 1; i++)
    {
        if (a[i] > 64 && a[i] < 91 || a[i] > 96 && a[i] < 123)
        {
            temp = i;
            break;
        }
    }
    return temp + 1;
}

int main()
{
    char a[A];
    printf("\n-----Nhap vao chuoi bat ki-----\n");
    fgets(a, A, stdin);
    printf("\n-----Vi tri chu cai dau tien-----\n");
    printf("%d", ViTriDauTien(a));
}