#include <stdio.h>
#include <string.h>
#define A 1000

void NoiChuoi(char a[], char b[])
{
    int j = 0, i, n = strlen(a) - 1, m = strlen(b) - 1;
    for (i = n; i < n + m; i++)
    {
        a[i] = b[j];
        j++;
    }
    a[i] = '\0';
}

int main()
{
    char a[A/2], b[A/2], c[A], d[A]; // chuoi copy nho hon chuoi chua
    printf("\n-----Nhap vao chuoi thu nhat-----\n");
    fgets(a, A, stdin);

    printf("\n-----Nhap vao chuoi thu hai-----\n");
    fgets(b, A, stdin);

    strcpy(d, a); // sao chep chuoi a vao chuoi d

    printf("\n-----Chuoi sau khi noi 1-----\n"); // (su dung ham)
    if (a[strlen(a) - 1] == '\n')
    {
        a[strlen(a) - 1] = '\0';
        strcpy(c, a); // sao chep chuoi a vao chuoi c
        strcat(c, b); // noi chuoi b vao chuoi c
        printf("%s", c);
    }
    
    printf("\n-----Chuoi sau khi noi 2-----\n"); // (khong su dung ham)
    NoiChuoi(d, b);
    printf("%s", d);
}