#include <stdio.h>
#include <string.h>
#define A 1000

void ChenChuoi(char a[], char b[], char c[], int n)
{
    int j = 0, t = 0, h = 0, k = strlen(b);

    if (b[k - 1] == '\n')
    {
        b[k - 1] = '\0';
    }
    

    for (int i = n; i < strlen(a) + n; i++)
    {
        c[t] = a[i]; // luu chuoi phia sau vi tri chen
        t++;
    }
    
    for (int i = n; i < strlen(a) + n; i++)
    {
        a[i] = b[j]; // chen chuoi
        j++;
    }

    for (int i = strlen(a); i < strlen(a) + k; i++)
    {
        a[i] = c[h]; // cap nhat chuoi chen
        h++;
    }
}

int main()
{
    char a[A], b[A], c[A];
    int n;
    printf("\n-----Nhap vao chuoi thu 1-----\n");
    fgets(a, A, stdin);

    printf("\n-----Nhap vao chuoi thu 2-----\n");
    fgets(b, A, stdin);

    printf("\n-----Nhap vao vi tri chen-----\n");
    scanf("%d", &n);

    ChenChuoi(a, b, c, n);

    printf("\n-----Chuoi sau khi chen-----\n");
    printf("%s", a);
}