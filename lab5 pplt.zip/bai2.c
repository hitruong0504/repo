#include <stdio.h>
#include <string.h>
#define A 1000

int DoDaiChuoi(char a[])
{
    int count = 0;
    while (a[count] != '\0')
    {
        count++;
    }
    return count - 1;
}
int main()
{
    char a[A];
    printf("\nNhap vao 1 chuoi bat ki: ");
    fgets(a, A, stdin);

    // 1
    for (int i = DoDaiChuoi(a); i >= 0; i--)
    {
        printf("%c", a[i]);
    }

    // 2
    printf("\n%s", strrev(a));
}