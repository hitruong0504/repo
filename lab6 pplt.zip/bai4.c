#include <stdio.h>

int P(int x, int n)
{
    if (n == 0)
    {
        return 1;
    }else if (n == 1)
    {
        return x;
    }else
    {
        return x * P(x, n - 1);
    }
}

int main()
{
    int n, x;
    printf("\nNhap x: ");
    scanf("%d", &x);

    printf("\nNhap n: ");
    scanf("%d", &n);

    printf("\nx mu n = %d.", P(x, n));
}