#include <stdio.h>

int giaithua(int n)
{
    if (n == 0 || n == 1)
    {
        return 1;
    }else
    {
        return n * giaithua(n - 1);
    }
}

int main()
{
    int n;
    printf("\nNhap vao so tinh giai thua: ");
    scanf("%d", &n);

    printf("\n%d giai thua bang %d.", n, giaithua(n));
}