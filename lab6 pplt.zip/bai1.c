#include <stdio.h>

int SNT(int n, int i)
{
    if (n == 1) return 0;
    if (i == 1) return 1;
    if (n % i == 0)
    {
        return 0;
    }else
    {
        return SNT(n, i - 1);
    }
    
    
}
int main()
{
    int n;
    printf("\nNhap so de kiem tra: ");
    scanf("%d", &n);

    if (SNT(n, n - 1) == 1)
    {
        printf("\n%d la SNT!", n);
    }else
    {
        printf("\n%d khong la SNT!", n);
    }
}