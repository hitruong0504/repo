#include <stdio.h>

int SCS(int n)
{
    if (n == 0)
    {
        return 0;
    }else
    {
        return 1 + SCS(n / 10);
    }
}

int main()
{
    int n;
    printf("\nNhap vao so nguyen duong bat ki: ");
    scanf("%d", &n);

    printf("\nSo nhap vao co %d chu so.", SCS(n));
}