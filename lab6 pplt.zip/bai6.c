#include <stdio.h>
#include <math.h>

// a
int sum1(int n)
{
    if (n == 0)
    {
        return 0;
    }else
    {
        return sum1(n - 1) + 2 * n + 1;
    }
}

// b
float sum2(int n)
{
    if (n == 1)
    {
        return 0.5;
    }else
    {
        return sum2(n - 1) + n / 2.0;
    }
}

// c
int giaithua(int n)
{
    if (n == 1)
    {
        return 1;
    }else
    {
        return n * giaithua(n - 1);
    }
}


int sum3(int n)
{
    if (n == 1)
    {
        return 1;
    }else
    {
        return sum3(n - 1) + giaithua(n - 1) * n;
    }
}

// d
float sum4(int n)
{
    if (n == 0)
    {
        return 0;
    }else
    {
        return sum4(n - 1) + sqrt(n*1.0);
    }
}

// e
int mul(int n)
{
    if (n == 1)
    {
        return 1;
    }else
    {
        return mul(n - 1) * giaithua(n - 1) * n;
    }
}
int main()
{
    int n;
    printf("\nNhap n: ");
    scanf("%d", &n);

    printf("cau a: %d", sum1(n));
    printf("\ncau b: %.1f", sum2(n));
    printf("\ncau c: %d", sum3(n));
    printf("\ncau d: %.1f", sum4(n));
    printf("\ncau e: %d", mul(n));
}