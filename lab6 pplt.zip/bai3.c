#include <stdio.h>

int pow1(int n)
{
    if (n == 0)
    {
        return 1;
    }else if (n == 1)
    {
        return 2;
    }else
    {
        return 2 * pow1(n - 1);
    }
}

int main()
{
    int n;
    printf("\nNhap n: ");
    scanf("%d", &n);

    printf("\n2 mu n = %d.", pow1(n));
}